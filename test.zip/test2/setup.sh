sudo apt update
git clone https://github.com/neotokyo/test2
mv ~/test2/ProjetoBD ~/
cd ~/ProjetoBD
sudo apt-get install python3-venv
sudo python3 -m venv .
source bin/activate
cd ~/ProjetoBD/Prototipo
sudo chown -R $USER:$USER ~/ProjetoBD
pip install -r requirements.txt
sudo apt-get install zstd
curl -fsSL https://ollama.com/install.sh | sh
sudo apt-get install postgresql-client
sudo apt-get install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
cd ~/ProjetoBD
sudo -u postgres createdb eventos
sudo -u postgres psql -d eventos -f DML.sql
ollama pull qwen3:8b
sudo -u postgres psql -c "ALTER USER postgres PASSWORD 'postgres';"
python3 ~/ProjetoBD/Prototipo/main.py
